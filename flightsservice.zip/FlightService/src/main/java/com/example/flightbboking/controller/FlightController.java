package com.example.flightbboking.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.flightbboking.model.Flight;
import com.example.flightbboking.model.repository.FlightRepo;

//@RestController
@RequestMapping("/flights")
public class FlightController{
	
	

	@Autowired
	FlightRepo filghtrepo;

	@GetMapping("/getAllFlights")
	public List<Flight> getLists(){
	return filghtrepo.findAll();
	}
	
	@PostMapping("/addFlight")
	public String addBookingRecord(@RequestBody Flight  fare) {
		filghtrepo.save(fare);
	return "records are added";
	}
	
	
	  @GetMapping("/get/{id}") public Optional<Flight> getlist(@PathVariable int
	  id){ return filghtrepo.findById(id); }
	 
	
	
	
	
	  @DeleteMapping("/delete/{id}") public String deletebyId(@PathVariable int id)
	  { filghtrepo.deleteById(id); return "record deleted with id"; }
	 
}


