package com.example.flightbboking.model.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.flightbboking.model.Fare;


public interface FaresRepository extends MongoRepository<Fare, Integer> {
	


}
