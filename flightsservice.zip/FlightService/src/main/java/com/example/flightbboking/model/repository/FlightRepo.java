package com.example.flightbboking.model.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.flightbboking.model.Flight;

public interface FlightRepo extends MongoRepository<Flight,Integer> {
	

}
