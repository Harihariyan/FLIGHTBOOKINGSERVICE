package com.example.flightbboking.model;


	
	
	import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Document;



	@Document(collection="Fare")
	public class Fare {
		@Id
	    private Integer id;
		
		private String flightNumber;
		String origin;
		String destination;
		private String flightDate;
		private String fare;
		
		public Fare() {
			super();
		}


		


		public Fare(Integer id, String flightNumber, String origin, String destination, String flightDate, String fare) {
			super();
			this.id = id;
			this.flightNumber = flightNumber;
			this.origin = origin;
			this.destination = destination;
			this.flightDate = flightDate;
			this.fare = fare;
		}





		public String getOrigin() {
			return origin;
		}





		public void setOrigin(String origin) {
			this.origin = origin;
		}





		public String getDestination() {
			return destination;
		}





		public void setDestination(String destination) {
			this.destination = destination;
		}





		public Integer getId() {
			return id;
		}


		public void setId(Integer id) {
			this.id = id;
		}


		public String getFlightNumber() {
			return flightNumber;
		}


		public void setFlightNumber(String flightNumber) {
			this.flightNumber = flightNumber;
		}


		public String getFlightDate() {
			return flightDate;
		}


		public void setFlightDate(String flightDate) {
			this.flightDate = flightDate;
		}


		public String getFare() {
			return fare;
		}


		public void setFare(String fare) {
			this.fare = fare;
		}


		@Override
		public String toString() {
			return "Fares [id=" + id + ", flightNumber=" + flightNumber + ", flightDate=" + flightDate + ", fare=" + fare
					+ "]";
		}
		
	}
		
		
		