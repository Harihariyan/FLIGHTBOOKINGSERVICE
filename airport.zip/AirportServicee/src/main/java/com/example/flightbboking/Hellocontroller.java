package com.example.flightbboking;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Hellocontroller {
	@RequestMapping("/hello")
	public String helloworld()
	{
		return "Hello Airport Service";
	}

}
