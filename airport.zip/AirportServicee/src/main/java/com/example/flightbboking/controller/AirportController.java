package com.example.flightbboking.controller;

 import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.flightbboking.model.Airport;
import com.example.flightbboking.model.Flight;
import com.example.flightbboking.model.Fares;
import com.example.flightbboking.repository.AirportRepository;

@RestController
@RequestMapping("/airport")
public class AirportController {

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private AirportRepository repository;

	
	@GetMapping("/hello")
	public String printHello() {
		return "Hello Passenger";
	}
	
	
	/*
	 * @RequestMapping("/faredetails/{Id}") public Fares
	 * getFareDetails(@PathVariable int Id){
	 * System.out.println("calling airport from booking"); Fares fare=
	 * restTemplate.getForObject("http://localhost:9090/fares/list/"+ Id,
	 * Fares.class); return fare; }
	 */
	
	/*
	 * @RequestMapping("/flightDetails/{destination}") public Flight
	 * getFlightDetail(@PathVariable String destination){
	 * System.out.println("calling flight details from airport"); Flight flight=
	 * restTemplate.getForObject("http://localhost:9090/flights/get/"+ destination,
	 * Flight.class); return flight; }
	 */
	
	@RequestMapping("/flightDetails/{Id}")
	public Flight getFlightDetails(@PathVariable int Id){
		System.out.println("calling flight details from airport");
  		Flight flight= restTemplate.getForObject("http://localhost:8083/flights/get/"+ Id, Flight.class);
  		return flight;
	}
	
	/*
	 * @RequestMapping("/flightDetails/") public List<Flight> getAllFlightDetails(){
	 * System.out.println("calling flight details from airport"); List<Flight>
	 * flight= (List<Flight>)
	 * restTemplate.getForObject("http://localhost:9090/flights/getAllFlights",
	 * Flight.class); return flight; }
	 */
	
	@PostMapping("/add")
	public String saveAirport(@RequestBody Airport airport) {
		repository.save(airport);
		return "Added airport with id : "+airport.getAirportId();
	}
	
	@GetMapping("/findAll")
	public List<Airport> getAirports(){
		return repository.findAll();
	}
	
	
	@GetMapping("/findAll/{airportId}")
	public Optional<Airport> getAirport(@PathVariable int airportId){
		return repository.findById(airportId);
	}
	
	@DeleteMapping("/delete/{airportid}")
	public String deleteAirport(@PathVariable int airportId) {
		repository.deleteById(airportId);
		return "Book deleted with id : "+airportId;
		
	}
}

