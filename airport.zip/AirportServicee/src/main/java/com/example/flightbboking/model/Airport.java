package com.example.flightbboking.model;


	import org.springframework.data.annotation.Id;
	import org.springframework.data.mongodb.core.mapping.Document;


	@Document(collection="Airport")
	public class Airport {

		
		@Id
		private int airportId;
		private String airportName;
		
		
		public Airport() {}

		public Airport(int airportId, String airportName) {
		super();
		this.airportId = airportId;
		this.airportName = airportName;
		
		}



		public int getAirportId() {
		return airportId;
		}


		public void setAirportId(int airportId) {
		this.airportId = airportId;
		}


		public String getAirportName() {
		return airportName;
		}


		public void setAirportName(String airportName) {
		this.airportName = airportName;
		}


		


		@Override
		public String toString() {
		return "Airport [airportId=" + airportId + ", airportName=" + airportName +  "]";
		}


	}



