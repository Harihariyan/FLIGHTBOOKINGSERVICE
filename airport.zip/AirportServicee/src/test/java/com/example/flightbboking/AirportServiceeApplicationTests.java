package com.example.flightbboking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirportServiceeApplicationTests {

	@Test
	void contextLoads() {
	}

}
