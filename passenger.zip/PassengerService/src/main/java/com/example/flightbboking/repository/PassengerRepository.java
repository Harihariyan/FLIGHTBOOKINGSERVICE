package com.example.flightbboking.repository;


	import org.springframework.data.mongodb.repository.MongoRepository;

	import com.example.flightbboking.model.Passenger;

	public interface PassengerRepository extends MongoRepository<Passenger, Integer>{

	}



