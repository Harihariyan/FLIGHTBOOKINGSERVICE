package com.example.flightbboking.component;

import org.springframework.stereotype.Component;

import com.example.flightbboking.model.BookingRecord;
import com.example.flightbboking.repository.BookingRepository;
import com.example.flightbboking.repository.InventoryRepository;

@Component
public class BookingComponent {
	
	BookingRepository bookingRepository;
	InventoryRepository inventoryRepository;

	
	public void book(BookingRecord record) {
		bookingRepository.save(record);
	}
}


