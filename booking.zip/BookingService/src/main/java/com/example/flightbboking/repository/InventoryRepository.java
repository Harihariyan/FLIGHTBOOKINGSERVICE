package com.example.flightbboking.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.flightbboking.model.Inventory;

public interface InventoryRepository extends MongoRepository<Inventory, Long> {

	Inventory findByFlightNumberAndFlightDate(String flightNumber, String flightDate);
	
}


