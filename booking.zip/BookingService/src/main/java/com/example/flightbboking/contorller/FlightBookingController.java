package com.example.flightbboking.contorller;

import java.util.List;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.flightbboking.model.Fare;
//import com.example.flightbboking.model.Airport;
import com.example.flightbboking.model.BookingRecord;
import com.example.flightbboking.model.Passenger;
import com.example.flightbboking.repository.BookingRepository;

@RestController
@RequestMapping("/booking")
public class FlightBookingController {
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private BookingRepository bookingrepo;
	
	
	@RequestMapping("/faredetails/{Id}")
	public Fare getFareDetails(@PathVariable int Id){
		System.out.println("calling airport from booking");
  		Fare fare= restTemplate.getForObject("http://localhost:8083/fares/list/"+ Id, Fare.class);
  		return fare;
	}
	
	/*
	 * @RequestMapping("/airportdetails/{airportId}") public Airport
	 * getAirport(@PathVariable int airportId){
	 * System.out.println("calling airport from booking"); Airport airport=
	 * restTemplate.getForObject("http://localhost:9092/airport/findAll/"+
	 * airportId, Airport.class); return airport; }
	 */
	
	@RequestMapping("/passengers/{Id}")
	public Passenger getpassengers(@PathVariable int Id){
		System.out.println("calling passenger from booking");
		Passenger pass= restTemplate.getForObject("http://localhost:9093/passenger/getpass/"+ Id, Passenger.class);
  		return pass;
	}
	
	@GetMapping("/list")
	public List<BookingRecord> getList(){
		return  bookingrepo.findAll();
	}
	
	
	@PostMapping("/addrecord")
	public String addBookingRecord(@RequestBody BookingRecord bookingRecord) {
		bookingrepo.save(bookingRecord);
		return "records are added";
	}
    @PutMapping("/update/{id}")
    public String getbyId(@PathVariable String id,@RequestBody BookingRecord bookingRecord) {
	  BookingRecord  bookingId=bookingrepo.findById(id).get();
	  bookingId.setId(bookingRecord.getId());
	  bookingId.setFlightNumber(bookingRecord.getFlightNumber());
	  bookingId.setOrigin(bookingRecord.getOrigin());
	  bookingId.setDestination(bookingRecord.getDestination());
	  bookingId.setFlightDate(bookingRecord.getFlightDate());
	  bookingId.setBookingDate(bookingRecord.getBookingDate());
	  bookingId.setFare(bookingRecord.getFare());
	  bookingId.setStatus(bookingRecord.getStatus());
	  bookingrepo.save(bookingId);
	  return "updated bookingRecord";
  }
	

	@DeleteMapping("/delete/{id}")
	public String deletebyId(@PathVariable String id) {
	bookingrepo.deleteById(id);
	return "bookingrecord deleted with id";
	}

}